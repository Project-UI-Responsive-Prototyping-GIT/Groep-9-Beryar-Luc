<footer>
        <section id="footer">
            <article id="logoArt">
                <a href="../Home/Home.php"><img id="logo" src="../img/MicrosoftTeams-image.png" alt="logo"></a>
            </article>
            <article class="contact">
                <h1> Contact: </h1> <br>
                <p class="contact1">Blablabla@gmail.com</p>
                <p class="contact1"> 0686549845 </p>
                <p class="contact1"> Soliciteren? <a id="VacaRedirect" href="../Vacatures/Vacatures.php">Klik Hier!</a> </p>
            </article>
            <article class="contact" id="socialmedia">
                <a href="https://www.instagram.com/azteccasitc/?igsh=eGE1cWY1ZG0wMDM5" target="_blank" rel="noreferrer noopener"><img src="../img/instagram.png" alt="insta" height="40px" width="40px"></a>
                <a href="#"><img src="../img/facebook.png" alt="insta" height="40px" width="40px"></a>
                <a href="#"><img src="../img/twitter.png" alt="insta" height="40px" width="40px"></a>
            </article>
        </section>
</footer>